---
name: flip-ux-writing
description: Use whenever writing, reviewing, or rewriting UX copy, microcopy, error messages, notifications, onboarding text, or any user-facing text for Flip products. Applies Flip's glossary, writing guidelines, mechanics rules, and tone-of-voice (from a bundled data snapshot, refreshed periodically from the Flip Communication Hub) together with general UX writing craft principles to check existing copy or draft new copy.
---

# Flip UX Writing

Writing or reviewing user-facing copy for a Flip product means satisfying two different kinds of requirements at once: Flip's own house rules (facts — approved terms, do/don't examples, brand tone) and general UX-writing craft (judgment — what actually makes copy clear, humane, and usable). This skill supplies both.

## Workflow

**1. Read `references/flip-data-snapshot.json`** for Flip's terminology, guidelines, mechanics rules, and per-product tone-of-voice. This is the primary and default source — read it directly as a local file, no network access needed. It contains:

- `glossary` — approved terms, their `avoid` lists, definitions, categories
- `guidelines` — published writing guidelines (`null` if none are currently published)
- `mechanics` — punctuation/capitalization/date-time/formatting rules
- `tone` — an array of `{ product, brandConstants, tonePillars }`, one per product (`flip-core`, `flip-deals`, `flip-globe`, `flip-emas`)

Check the top-level `snapshot_fetched_at` field and mention its age if it looks stale (say, more than a few weeks old) — the underlying dashboard content can change and this file only updates when someone re-runs the refresh command below.

**2. Optionally, try fetching live data first, but never block on it.** If your environment happens to have working web access to `https://flip-comm-hub.vercel.app/api/v1/` (true in some setups, e.g. Claude Code with WebFetch — **not** reliable in claude.ai's assistant chat, which restricts fetches to an allowed-domain list that doesn't include arbitrary `vercel.app` subdomains), a live fetch is more current than the bundled snapshot and fine to prefer if it succeeds. But treat this as a bonus, not a requirement: if the fetch fails, times out, or the tool isn't available at all, silently fall back to the snapshot from step 1 — don't surface the failure as an error, and don't block the task on it. Never claim data is "live" unless a fetch actually succeeded in that turn.

**3. Read `references/ux-writing-craft.md`** for the general UX-writing principles that apply to the task at hand — voice/tone application, the relevant microcopy pattern (button, error message, empty state, etc.), accessibility considerations, and bilingual EN/ID guidance if the copy is Indonesian, English, or both.

**4. Apply both together.**

- Flip's glossary/guidelines/mechanics/tone are **hard constraints**: approved terms and their avoid-lists, mechanics rules (punctuation, capitalization, date/currency formatting), and the specific product's tone pillars/brand constants are not optional style preferences — they're what "correct" means for this task.
- The craft reference is **the reasoning for how to satisfy those constraints well** — e.g. the tone pillars say "Friendly," the craft doc's voice/tone section is what turns that into an actual sentence structure and word choice for *this* specific error message.

**When reviewing existing copy:** produce a list of flagged issues, each citing the specific rule, term, or pillar it relates to, plus a suggested rewrite for each — and a full suggested rewrite of the whole passage at the end. Don't just say "this doesn't sound like Flip" — point to what specifically, per the snapshot data, made that judgment.

**When drafting new copy:** write it directly against the fetched constraints and the relevant craft pattern, then briefly note which glossary terms/tone pillars/mechanics rules shaped the result, so the requester can sanity-check the reasoning.

## Keeping the snapshot fresh

`references/flip-data-snapshot.json` is a point-in-time copy, not a live connection. Refresh it by re-running this and committing/copying the updated file wherever the skill is installed:

```bash
curl -s https://flip-comm-hub.vercel.app/api/v1/all | python3 -c "
import json, sys, datetime
raw = json.load(sys.stdin)
wrapped = {
    'snapshot_fetched_at': datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z'),
    'source': 'https://flip-comm-hub.vercel.app/api/v1/all',
    'data': raw['data'],
}
print(json.dumps(wrapped, indent=2, ensure_ascii=False))
" > references/flip-data-snapshot.json
```

Do this after any meaningful dashboard update (new terms, a tone change, a new guideline published), or on whatever cadence feels reasonable — there's no automatic trigger for it.

## Notes

- This skill has no write access to the Flip Communication Hub — it only reads. If a glossary term is missing or a rule seems wrong, say so and suggest the requester raise it with whoever maintains the dashboard, rather than working around it silently.
- The snapshot only ever contains `status: 'published'` glossary terms and respects the dashboard's section-visibility toggles as of the moment it was fetched — it reflects exactly what was live on the public site then, nothing draft.
