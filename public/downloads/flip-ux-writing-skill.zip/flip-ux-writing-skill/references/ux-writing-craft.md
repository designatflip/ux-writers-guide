# UX Writing Craft Reference

General principles for writing user-facing product copy. Use this alongside Flip's live glossary/guidelines/mechanics/tone (fetched per `SKILL.md`'s workflow) — this document is the *how*, Flip's data is the *what*.

## Core principles

- **Clear over clever.** If a reader has to pause to parse it, it's failed. Prefer the plain word over the impressive one ("use" not "utilize," "help" not "facilitate").
- **Concise, not truncated.** Cut words that don't carry meaning ("please note that," "in order to," "simply"). Don't cut words the reader needs — a terse message that omits *why* or *what to do next* isn't concise, it's incomplete.
- **Actionable.** Every piece of copy should make it obvious what the reader can or should do next, or clearly communicate that no action is needed.
- **Conversational, not casual-for-its-own-sake.** Write like a knowledgeable person talking to the reader, not like a legal disclaimer or a hype-y ad. Contractions are usually fine; forced slang usually isn't.
- **Consistent.** The same concept gets the same word every time (this is what the glossary enforces) — a UI that calls the same thing "top up," "add funds," and "recharge" in three different screens makes the reader do translation work that isn't theirs to do.

## Voice & tone: applying brand pillars to actual sentences

A brand pillar like "Friendly" or "Fair" is not itself copy — it's a constraint on the copy you write. The craft is translating it:

- **Read the pillar's `description`, `do_example`, and `dont_example`** (from the tone API) literally. The do/don't pair is almost always more useful than the abstract label — it shows the actual register, sentence length, and word choice that counts as "on brand" versus not.
- **Tone shifts with the moment, even within one brand voice.** The same brand can and should sound different in a celebratory moment ("You just saved Rp50,000!") versus a cautionary one ("This transfer can't be undone — check the account number before continuing") versus a purely transactional one (a form label, a timestamp). Match formality and energy to what's actually happening for the user, not just to a fixed brand register applied uniformly everywhere.
- **Don't let "friendly" become "vague."** Warmth in tone should never come at the cost of clarity about what happened or what to do. A friendly error message still says exactly what went wrong.
- **Brand constants over house style when they conflict.** If a product's brand constants say something specific (e.g. "always name the exact fee up front"), that's a harder rule than the general craft guidance below — apply the specific before the general.

## Microcopy patterns by UI moment

**Buttons & CTAs**
- Lead with the verb, name the object: "Send money," not "Submit" or "Continue" when a more specific label is possible.
- Match the button to the actual consequence — if tapping it charges money or can't be undone, the label should make that legible ("Confirm and pay," not just "OK").

**Form labels & field help**
- Labels name the field; helper text explains constraints or format *before* the user gets it wrong ("8-15 digits," not just showing an error after submission if it's avoidable).
- Only show inline error text once there's an actual error — don't pre-emptively scold.

**Error messages**
Three parts, in order, and not all three are always needed:
1. **What happened** — in plain language, not a raw error code or internal state name.
2. **Why** (only if it helps the user understand or trust the message — skip if it's just noise).
3. **What to do next** — the single most useful next action. If there's genuinely nothing the user can do, say that plainly ("This isn't something you can fix — contact support") rather than implying an action exists.

Never blame the user ("You entered an invalid number" reads worse than "That doesn't look like a valid phone number — check the format and try again"). Never surface a raw technical error code, stack trace, or internal status enum to an end user without a plain-language translation alongside it.

**Empty states**
- Explain what will appear here once there's something to show, not just "No data."
- Where there's a clear next action (e.g. "You have no transactions yet"), offer it directly rather than leaving a dead end.

**Loading states**
- If a wait is short and expected, a plain spinner/label is enough ("Loading…"). If it can run long or the user might worry something's wrong, say what's happening ("Verifying your payment — this can take up to a minute").

**Success / confirmation messages**
- Confirm specifically what happened, not just "Success." ("Transfer of Rp100,000 sent to Budi" beats "Done!") — specificity is also what makes an error message's *absence* trustworthy later.

**Notifications**
- Front-load the most important information — many notification UIs truncate; don't bury the point in a dependent clause at the end.

**Onboarding**
- Explain value before asking for effort. Each step should make it obvious why the user is being asked for it.

**Tooltips**
- Reserve for genuinely non-obvious information. A tooltip that just restates the label it's attached to is a sign the label itself needs work instead.

## Accessibility & plain language

- Write for a broad reading level by default — avoid idioms, culturally-specific references, and jargon that assumes prior product or financial-services knowledge, unless the audience is confirmed expert.
- Link text should describe the destination ("View transaction history," not "click here").
- If writing alt text: describe what's functionally relevant about the image, not everything visible in it — for a decorative image, empty alt text (`alt=""`) is correct so screen readers skip it.
- Numbers, currency, and dates: state them unambiguously and consistently — this is exactly what Flip's mechanics rules govern (date format, currency formatting, number grouping); treat those as accessibility rules, not just style ones, since inconsistent formatting is a real comprehension barrier, not just a polish issue.

## Bilingual copy (English + Bahasa Indonesia)

- **Terminology must match across languages**, not just be individually correct — this is exactly what the glossary's `term`/`term_bahasa` pairing exists to enforce. Before finalizing bilingual copy, check that a given concept uses its paired term in both languages, not a synonym that happens to also be correct.
- **Don't translate literally.** A phrase that's natural and on-tone in English can be stiff, overly formal, or just wrong-register when translated word-for-word into Indonesian (and vice versa) — write the Indonesian version as its own sentence aiming at the same intent and tone, not as a translation exercise.
- **Formality conventions differ.** Bahasa Indonesia has a wider and more context-sensitive range of formality markers than English; match the brand's actual register (check `do_example`/`dont_example` in Indonesian if available) rather than defaulting to either extreme.
- **Check both directions.** If the source copy was drafted in English, review the Indonesian for naturalness; if drafted in Indonesian first, do the same check on the English.

## Review checklist

When reviewing existing copy (per `SKILL.md` step 3), work through this list and cite the specific fetched rule/term/pillar for anything flagged:

1. **Terminology** — does every product/feature/concept use its approved glossary term? Any avoid-listed words present?
2. **Mechanics** — punctuation, capitalization, date/time/currency formatting all match the fetched mechanics rules?
3. **Tone** — does the copy match the relevant product's tone pillars and brand constants, with a specific do/don't example to point to (not just a vibe judgment)?
4. **Guideline compliance** — does the copy follow any relevant published writing guideline?
5. **Clarity & actionability** — plain language, no jargon/raw error codes, clear next step where one exists?
6. **Moment-appropriate microcopy pattern** — does it follow the pattern above for what kind of UI moment this is (error, empty state, confirmation, etc.)?
7. **Bilingual consistency** — if both languages are present, do they say the same thing in matched terminology and equivalent (not identical) tone?

Then produce: a list of flagged issues (each citing what triggered it) with a suggested fix per issue, and one full suggested rewrite of the passage incorporating all fixes together.
