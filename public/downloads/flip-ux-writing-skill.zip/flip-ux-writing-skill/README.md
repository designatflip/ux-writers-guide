# Flip UX Writing — Claude Skill

A Claude Skill that writes and reviews user-facing copy for Flip products by combining:

- **Flip's house rules** — glossary, writing guidelines, mechanics (punctuation/formatting), and per-product tone-of-voice — bundled inside the skill as `references/flip-data-snapshot.json`, a periodically-refreshed snapshot from the Flip Communication Hub's public API. (An earlier version tried fetching this live on every use, but claude.ai's assistant chat restricts which domains it can fetch from — `vercel.app` isn't on that allowed list — so a live fetch can't be relied on in every environment. Bundling it works everywhere, at the cost of needing an occasional manual refresh — see below.)
- **General UX-writing craft** — voice/tone application, microcopy patterns, error-message structure, accessibility, and EN/ID bilingual guidance — in `references/ux-writing-craft.md`.

Ask Claude to write or check copy against Flip's guidelines and it'll pull both together: Flip's data as the hard constraints, the craft reference as the reasoning for how to satisfy them well.

## Install

This is a standalone package — not tied to any repo. Copy the whole `flip-ux-writing-skill/` folder into a Claude skills directory:

- **Just for you, across all your projects:** copy it to `~/.claude/skills/flip-ux-writing/`
- **For one specific project (shared with anyone using Claude Code there):** copy it to `<project>/.claude/skills/flip-ux-writing/`

```bash
# personal, all projects
cp -r flip-ux-writing-skill ~/.claude/skills/flip-ux-writing

# one project
cp -r flip-ux-writing-skill /path/to/project/.claude/skills/flip-ux-writing
```

No API key, no build step, no dependencies — it's a couple of markdown files plus one JSON data file. Claude Code will pick it up automatically and load it whenever the task looks like writing or reviewing UX copy for Flip. **Start a new session after copying it in** — skills load at session start, so an already-running chat won't see it.

## Using it in claude.ai (not just Claude Code)

Claude.ai supports uploading Skills too (Settings → Capabilities → Skills, on plans that support it) — zip the `flip-ux-writing-skill/` folder and upload it there if you want the same behavior outside Claude Code.

## Using it outside Claude entirely

Everything in this folder is plain text — `SKILL.md`, `references/ux-writing-craft.md`, and `references/flip-data-snapshot.json` can all be opened in any text editor. For a coworker on ChatGPT or another tool: paste the contents of those files at the start of a conversation (or into a custom GPT's instructions field) before asking their copy question.

## What's inside

```
flip-ux-writing-skill/
  SKILL.md                          # trigger description + the workflow Claude follows
  references/
    ux-writing-craft.md             # general UX-writing craft knowledge
    flip-data-snapshot.json         # bundled glossary/guidelines/mechanics/tone data
  README.md                         # this file
```

## Keeping the data snapshot current

`references/flip-data-snapshot.json` is a point-in-time copy of `GET /api/v1/all` from the Flip Communication Hub, not a live connection — check its `snapshot_fetched_at` field to see how old it is. Refresh it with:

```bash
curl -s https://flip-comm-hub.vercel.app/api/v1/all | python3 -c "
import json, sys, datetime
raw = json.load(sys.stdin)
wrapped = {
    'snapshot_fetched_at': datetime.datetime.now(datetime.timezone.utc).isoformat().replace('+00:00', 'Z'),
    'source': 'https://flip-comm-hub.vercel.app/api/v1/all',
    'data': raw['data'],
}
print(json.dumps(wrapped, indent=2, ensure_ascii=False))
" > references/flip-data-snapshot.json
```

Run this after any meaningful dashboard update, then re-copy the updated file to wherever the skill is installed (`~/.claude/skills/flip-ux-writing/`, any project's `.claude/skills/`, or wherever else you've shared it). There's no automatic refresh — someone has to run this.

The craft reference (`ux-writing-craft.md`) is static and edited directly — treat it like any other doc: update it when the team's thinking on UX writing craft evolves.

## Limitations

- Read-only. It can flag that a glossary term looks wrong or a rule seems missing, but it can't fix the source data — that still goes through the Flip Communication Hub dashboard.
- The bundled data can go stale between refreshes — the skill will mention the snapshot's age if it looks old, but it won't know about a dashboard change made five minutes ago.
